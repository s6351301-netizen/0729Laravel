<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CarController extends Controller
{
    public function index()
    {

        // dd('123');
        $data = DB::select('select * from cars');
        // $data = DB::table('cars')->get()->toArray();
        // dd($data);
        // dd('hello CarController index');
        return view('car.index')->with(['data' => $data]);
    }

    public function r1()
    {
        // dd('hello CarController index');
        return view('car.r1');
    }

    public function r2()
    {
        // dd('hello CarController index');
        return view('car.r2');
    }
    public function b1()
    {
        // dd('hello CarController index');
        return view('car.b1');
    }

    public function b2()
    {
        // dd('hello CarController index');
        return view('car.b2');
    }
}
