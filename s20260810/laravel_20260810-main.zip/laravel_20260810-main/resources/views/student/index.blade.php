@extends('layouts.app')

@section('title', 'Student Title')


@section('content')
    <h3>Student Index child</h3>
    <p> Hello views student index</p>
@endsection
