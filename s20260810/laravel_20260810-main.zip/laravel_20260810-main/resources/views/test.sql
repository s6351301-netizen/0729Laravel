CREATE TABLE `laravel_20260810`.`cars` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(20) NULL DEFAULT NULL,
    PRIMARY KEY (`id`)
) ENGINE = InnoDB;

INSERT INTO
    `cars` (`id`, `name`)
VALUES
    (NULL, 'amy'),
    (NULL, 'bob'),
    (NULL, 'cat');

SELECT
    *
FROM
    `cars`