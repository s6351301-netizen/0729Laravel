@extends('layouts.app')

@section('title', 'Teacher Title')

@section('content')
    <h3>Teacher Index child</h3>
    <p> Hello views teacher index</p>
@endsection
