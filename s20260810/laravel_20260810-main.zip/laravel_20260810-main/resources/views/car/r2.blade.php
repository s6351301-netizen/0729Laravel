@extends('layouts.red')

@section('title', 'R1 Title')

{{-- @section('sidebar')
    @@parent

    <p>This is appended to the master sidebar.</p>
@endsection --}}

@section('content')
    <p>This is my body R2 content.</p>
@endsection
