<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CarController;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\TeacherController;

//teacher
Route::resource('teachers', TeacherController::class);

//student
Route::resource('students', StudentController::class);

// car
Route::get('/cars', [CarController::class, 'index']);
Route::get('/cars_r1', [CarController::class, 'r1']);
Route::get('/cars_r2', [CarController::class, 'r2']);
Route::get('/cars_b1', [CarController::class, 'b1']);
Route::get('/cars_b2', [CarController::class, 'b2']);

// Route::get('/', function () {
//     return view('welcome');
// });
